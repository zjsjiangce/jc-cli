if (typeof window.fetch === 'undefined') {
  require('whatwg-fetch')
}
