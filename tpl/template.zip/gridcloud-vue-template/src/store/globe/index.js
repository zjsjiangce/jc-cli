import * as modules from './modules/*.js'

const state = {}

const mutations = {}

const actions = {}

export default {
  namespaced: true,
  state,
  mutations,
  actions,
  modules,
}
